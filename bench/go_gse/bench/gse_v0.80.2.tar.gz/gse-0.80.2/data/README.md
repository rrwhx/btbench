# data

Gse segment templates and dictionaries