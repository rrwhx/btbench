Some dict/zh data is from [github.com/fxsjy/jieba](https://github.com/fxsjy/jieba)
