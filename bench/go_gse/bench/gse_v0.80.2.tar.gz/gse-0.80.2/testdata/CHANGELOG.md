# CHANGELOG

<!--### RobotGo-->

## Gse v0.60.0, Green Lake

add TF-IDF and text rank support
add SegPos and HMM pos support
add more HMM support, add SuggestFreq() support

add stop word support
add trim word support ( trim symbol and trim with pos... )
add filter emoji, symbol and language support

add PosStr and CutStr support
add skip log and pos set support
add multiple load dictionary support

add more example and test code 
Refactor test code

optimize code and fixed bug
...