//go:build ne
// +build ne

package gse

var (
	ja, zhT, zhS string
	stopDict     string
)
