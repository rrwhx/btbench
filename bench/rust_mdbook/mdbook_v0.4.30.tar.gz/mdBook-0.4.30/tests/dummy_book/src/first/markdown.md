# Markdown tests

Tests for some markdown output.

## Tables

| foo | bar |
| --- | --- |
| baz | bim |

## Footnotes

Footnote example[^1], or with a word[^word].

[^1]: This is a footnote.

[^word]: A longer footnote.
    With multiple lines.
    Third line.

## Strikethrough

~~strikethrough example~~

## Tasklisks

- [X] Apples
- [X] Broccoli
- [ ] Carrots
