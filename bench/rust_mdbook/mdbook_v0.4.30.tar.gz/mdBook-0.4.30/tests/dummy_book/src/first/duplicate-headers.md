# Duplicate headers

This page validates behaviour of duplicate headers.

# Header Text

# Header Text

# header-text
