# Tasks

- [ ] Task 1
- [ ] Task 2
- [x] Completed Task 1
- [x] Completed Task 2

---

- [ ] **Important Task**
- [x] _Completed Important task_
