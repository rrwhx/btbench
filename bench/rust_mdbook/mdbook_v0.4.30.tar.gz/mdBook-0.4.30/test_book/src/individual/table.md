# Tables

| col1 | col2 |
| ---- | ---- |

---

| col1 | col2 |
| ---- | ---- |
| val1 | val2 |

---

| col1 | col2 | col 3 | col 4 | col 5 | col 6 |
| ---- | ---- | ----- | ----- | ----- | ----- |
| val1 | val2 | val3  | val5  | val4  | val6  |
| val1 | val2 | val3  | val5  | val4  | val6  |
| val1 | val2 | val3  | val5  | val4  | val6  |
| val1 | val2 | val3  | val5  | val4  | val6  |

---

| col1                                                                                                           | col2 | col 3                                                                                                          | col 4                                                                                                          | col 5 | col 6                                                                                                          |
| -------------------------------------------------------------------------------------------------------------- | ---- | -------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------- | ----- | -------------------------------------------------------------------------------------------------------------- |
| This is a simple demo book, which is intended to be used for verifying and validating style changes in mdBook. | val2 | val3                                                                                                           | val5                                                                                                           | val4  | val6                                                                                                           |
| val1                                                                                                           | val2 | val3                                                                                                           | val5                                                                                                           | val4  | val6                                                                                                           |
| val1                                                                                                           | val2 | val3                                                                                                           | val5                                                                                                           | val4  | This is a simple demo book, which is intended to be used for verifying and validating style changes in mdBook. |
| val1                                                                                                           | val2 | This is a simple demo book, which is intended to be used for verifying and validating style changes in mdBook. | This is a simple demo book, which is intended to be used for verifying and validating style changes in mdBook. | val4  | val6                                                                                                           |
