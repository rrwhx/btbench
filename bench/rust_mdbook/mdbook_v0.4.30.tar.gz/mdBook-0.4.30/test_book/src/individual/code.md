# Code

This section only does simple code blocks and inline code, detailed syntax highlight and stuff is in the languages section

---

```
This is a codeblock
```

---

This line contains `inline code`

---

````
escaping ``` in ```, fun, isn't is?
````

---

```bash,editable
This is an editable codeblock
```

---

```rust
// This links to a playpen
```
