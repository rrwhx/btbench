# Strikethrough

~~This is Striked~~

~~This is **strong**, _italic_ , **_both_** and striked~~
