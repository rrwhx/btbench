# Lists

1. A
2. Normal
3. Ordered
4. List

---

1. A
   1. Nested
   2. List
2. But
3. Still
4. Normal

---

- An
- Unordered
- Normal
- List

---

- Nested
  - Unordered
- List

---

- This
  1. Is
  2. Normal
- ?!
