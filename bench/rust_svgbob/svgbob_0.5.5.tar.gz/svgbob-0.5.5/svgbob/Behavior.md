
`.` will make a rounded corner for top-left and top-right
`,` will make a rounded corner, only on the top-left
`\`` will make a rounded corner for bottom-left
`'` will make a rounded corner for bottom-left and bottom-right

`+` will make a sharp corner when connected from 2 perpendicular lines.
will become a cross-section when connected from 4 directions (top, right, bottom, left)

`\*` is a small solid circle when connected to a line

`o` is a small clear circle when connected to a line
`O` is a bigger clear circle when connected to a line

`-` is a solid line
    when 3 `- - -` is separated by space will make a broken line

`|` is a vertical line

`~` is a broken line

`\_` is a lowered solid line

`:` is a vertical broken line

`!` is a vertical broken line

`<` will make an arrow to the left if a line connects from right

`>` will make an arrow to the right if a line connects from left

`V` will make an arrow pointing bottom if a line connects from top
    will make an arrow pointing bottom-left if a line connects from top-right
    will make an arrow pointing bottom-right if a line connects from top-left

`^` will make an upward arrow if a line connects from bottom 
    will make an arrow pointing top-left if a line connects from bottom-right
    will make an arrow pointing top-right if a line connects from bottom-left

