reset && cargo test --all --all-features
